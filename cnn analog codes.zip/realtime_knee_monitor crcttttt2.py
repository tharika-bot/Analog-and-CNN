import serial
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.layers import InputLayer as KInputLayer
import tensorflow as tf
import time
import math

# Custom InputLayer to handle batch_shape
class CompatibleInputLayer(KInputLayer):
    def __init__(self, *args, batch_shape=None, **kwargs):  # Changed from U+00A0 to regular space
        if batch_shape is not None:
            kwargs['batch_input_shape'] = batch_shape
        super().__init__(*args, **kwargs)

# Load model with custom objects
with tf.keras.utils.custom_object_scope({
    'InputLayer': CompatibleInputLayer,  # Fixed indentation
    'DTypePolicy': tf.keras.mixed_precision.Policy
}):
    model = load_model(
        "c:\\Users\\Senthil\\Desktop\\smart knee\\fine_tuned_lstm_model(1)(1).h5",
        compile=False
    )

# === Serial Communication ===
ser = serial.Serial('COM13', 9600, timeout=1)
ser.reset_input_buffer()
ser.reset_output_buffer()  # Add output buffer reset
time.sleep(3)  # Increased stabilization time
print("Listening to Arduino for IMU data...")

# === Parameters ===
SEQ_LEN = 20
FEATURES = 7
buffer = []
last_buzz_time = time.time()  # Initialize buzzer cooldown timer

def is_valid_data(ax, ay, az, gx, gy, gz):
    """Validate sensor data to ensure it falls within expected ranges."""
    # Check for invalid readings (-1 or 0)
    if -1 in (ax, ay, az, gx, gy, gz):
        return False
    if all(v == 0 for v in [ax, ay, az, gx, gy, gz]):
        return False
    
    # Define expected ranges for accelerometer and gyroscope data
    valid_range = {
        'accel': (-32768, 32767),  # 16-bit range
        'gyro': (-32768, 32767)     # 16-bit range
    }
    return (
        valid_range['accel'][0] <= ax <= valid_range['accel'][1]
        and valid_range['accel'][0] <= ay <= valid_range['accel'][1]
        and valid_range['accel'][0] <= az <= valid_range['accel'][1]
        and valid_range['gyro'][0] <= gx <= valid_range['gyro'][1]
        and valid_range['gyro'][0] <= gy <= valid_range['gyro'][1]
        and valid_range['gyro'][0] <= gz <= valid_range['gyro'][1]
    )

def check_sensor_orientation(ax, ay, az):
    """Check if sensor is oriented correctly"""
    # When standing straight:
    # Y should be around -1g (-16384)
    # Z should be close to 0
    # X should be close to 0
    
    y_correct = abs(ay) > 12000  # Check if Y has significant downward force
    z_range = abs(az) < 8000     # Z should not have much gravity
    x_range = abs(ax) < 8000     # X should not have much gravity
    
    return y_correct, z_range, x_range

def calculate_bending_angle(ax, ay, az):
    """Calculate the knee bending angle using accelerometer data."""
    try:
        ax_normalized = ax / 16384.0
        ay_normalized = ay / 16384.0
        az_normalized = az / 16384.0
        
        # Current formula (calculating X-axis rotation)
        denominator = math.sqrt(ay_normalized**2 + az_normalized**2)
        pitch = math.degrees(math.atan2(-ax_normalized, denominator))
        
        # Replace with Y-axis rotation formula:
        denominator = math.sqrt(ax_normalized**2 + az_normalized**2)
        pitch = math.degrees(math.atan2(ay_normalized, denominator))
        
        return max(0, min(90, abs(pitch) - 2))  # Reduced offset to 2°
        adjusted_angle = abs(pitch) - 5  # Subtract typical standing offset
        
        # Ensure angle is between 0 and 90
        return max(0, min(90, adjusted_angle))
    except:
        return 0

# Add this code in the main loop after getting sensor data:
while True:
    try:
        line = ser.readline().decode('utf-8').strip()
        if not line:
            continue

        print(f"Raw Data: {line}")
        parts = line.split(",")
        if len(parts) != 6:
            print("Invalid data format. Expected 6 values.")
            continue

        # Convert to float
        ax, ay, az, gx, gy, gz = map(float, parts)

        # Validate data with more strict criteria
        if not is_valid_data(ax, ay, az, gx, gy, gz) or (ax == 0 and ay == 0 and az == 0):
            print("Invalid sensor data. Skipping...")
            continue

        # Check sensor orientation
        y_ok, z_ok, x_ok = check_sensor_orientation(ax, ay, az)
        print("\nSensor Orientation Check:")
        print(f"Y-axis (Down): {'✅' if y_ok else '❌'}")
        print(f"Z-axis (Outward): {'✅' if z_ok else '❌'}")
        print(f"X-axis (Forward): {'✅' if x_ok else '❌'}")
        
        if not all([y_ok, z_ok, x_ok]):
            print("\nPlease adjust sensor position:")
            if not y_ok:
                print("- Rotate sensor until Y-axis points down")
            if not z_ok:
                print("- Adjust until Z-axis points outward from leg")
            if not x_ok:
                print("- Ensure X-axis points forward")

        # Calculate bending angle
        bending_angle = calculate_bending_angle(ax, ay, az)
        
        # Store in buffer and process
        features = [ax, ay, az, gx, gy, gz, bending_angle]
        buffer.append(features)
        if len(buffer) > SEQ_LEN:
            buffer.pop(0)

        if len(buffer) == SEQ_LEN:
            recent_angles = [f[6] for f in buffer[-5:]]  # Increased from 2 to 5 samples
            avg_angle = sum(recent_angles) / len(recent_angles)
            
            print("\033[H\033[J")
            print(f"Current Knee Angle: {avg_angle:.1f}°")
            
            if avg_angle < 60:
                position_status = "Normal"
                print("🟢 Normal Position")
                last_buzz_time = time.time()  # Reset timer when back to normal
            else:
                position_status = "OVEREXTENSION"
                print("🔴🔴🔴 OVEREXTENSION DETECTED!")
                # Add cooldown check and proper command format
                if time.time() - last_buzz_time > 1.5:  # 1.5 second cooldown
                    try:
                        ser.write(b'BUZZ\n')  # Add newline terminator
                        ser.flush()
                        last_buzz_time = time.time()
                    except Exception as e:
                        print(f"Buzzer error: {e}")

            print(f"\nPosition: {position_status}")
            print(f"Sensor Data - X: {ax:.0f}, Y: {ay:.0f}, Z: {az:.0f}")
            
            # Immediate feedback for dangerous angles
            if avg_angle >= 60:
                print("\n⚠️ WARNING: Reduce knee bend immediately!")
                ser.write(b'BUZZ')
            
            print("-" * 40)
            time.sleep(0.1)

    except KeyboardInterrupt:
        print("🔴 Program stopped by user.")
        break
    except Exception as e:
        print(f"Error: {e}")
        continue